import requests
import zipfile
import json
import time
from pathlib import Path

class FontDownloader:
    def __init__(self, assets_path="assets/fonts"):
        self.assets_path = Path(assets_path)
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.fonts = {
            'inter': {
                'name': 'Inter Variable',
                'repo': 'rsms/inter',
                'filename': 'InterVariable.woff2',
                'extract_pattern': 'InterVariable.woff2',
                'license': 'SIL Open Font License'
            },
            'mona_sans': {
                'name': 'Mona Sans Variable',
                'repo': 'github/mona-sans',
                'filename': 'MonaSans-Variable.woff2',
                'extract_pattern': 'Mona-Sans',
                'license': 'SIL Open Font License'
            }
        }

    def create_directory(self):
        self.assets_path.mkdir(parents=True, exist_ok=True)

    def get_latest_release_info(self, repo):
        api_url = f"https://api.github.com/repos/{repo}/releases/latest"
        response = self.session.get(api_url)
        response.raise_for_status()
        return response.json()

    def download_file(self, url, filename):
        response = self.session.get(url, stream=True)
        response.raise_for_status()
        with open(filename, 'wb') as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)

    def extract_font_from_zip(self, zip_path, extract_pattern, target_filename):
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Special handling for Mona Sans variable font extraction
            if extract_pattern == 'Mona-Sans':
                # Find any .woff2 file with Mona, Sans, and wght in the name
                candidate_files = [
                    f for f in zip_ref.filelist
                    if f.filename.endswith('.woff2')
                    and 'Mona' in f.filename
                    and 'Sans' in f.filename
                    and 'wght' in f.filename
                ]
                if not candidate_files:
                    raise FileNotFoundError(f"No Mona Sans variable .woff2 files found in the zip.")
                font_file = candidate_files[0]
            else:
                # Find any .woff2 file containing the extract_pattern (handles subfolders and bracketed names)
                candidate_files = [
                    f for f in zip_ref.filelist
                    if extract_pattern in f.filename and f.filename.endswith('.woff2')
                ]
                if not candidate_files:
                    raise FileNotFoundError(f"No .woff2 file containing '{extract_pattern}' found in zip.")
                font_file = candidate_files[0]

            font_data = zip_ref.read(font_file.filename)
            target_path = self.assets_path / target_filename
            with open(target_path, 'wb') as f:
                f.write(font_data)

    def download_inter_font(self):
        release_info = self.get_latest_release_info(self.fonts['inter']['repo'])
        download_url = next(
            (a['browser_download_url'] for a in release_info.get('assets', [])
             if a['name'].endswith('.zip') and 'Inter' in a['name']),
            None
        )
        if not download_url:
            version = release_info.get('tag_name', 'v4.1')
            download_url = f"https://github.com/rsms/inter/releases/download/{version}/Inter-{version.replace('v', '')}.zip"
        zip_filename = "inter_download.zip"
        self.download_file(download_url, zip_filename)
        self.extract_font_from_zip(
            zip_filename,
            self.fonts['inter']['extract_pattern'],
            self.fonts['inter']['filename']
        )
        if Path(zip_filename).exists():
            Path(zip_filename).unlink()

    def download_mona_sans_font(self):
        release_info = self.get_latest_release_info(self.fonts['mona_sans']['repo'])
        download_url = next(
            (a['browser_download_url'] for a in release_info.get('assets', [])
             if a['name'].endswith('.woff2') and 'Mona-Sans' in a['name']),
            None
        )
        if not download_url:
            download_url = next(
                (a['browser_download_url'] for a in release_info.get('assets', [])
                 if a['name'].endswith('.zip')),
                None
            )
        if download_url and download_url.endswith('.woff2'):
            target_path = self.assets_path / self.fonts['mona_sans']['filename']
            self.download_file(download_url, target_path)
        elif download_url:
            zip_filename = "mona_sans_download.zip"
            self.download_file(download_url, zip_filename)
            self.extract_font_from_zip(
                zip_filename,
                self.fonts['mona_sans']['extract_pattern'],
                self.fonts['mona_sans']['filename']
            )
            if Path(zip_filename).exists():
                Path(zip_filename).unlink()
        else:
            raise FileNotFoundError("Mona Sans font file not found in release assets.")

    def generate_css_file(self):
        css_content = """/* Variable Fonts for TENET Tech Portfolio */
@font-face {
    font-family: 'InterVariable';
    src: url('InterVariable.woff2') format('woff2-variations');
    font-weight: 100 900;
    font-style: normal;
    font-display: swap;
}
@font-face {
    font-family: 'MonaSans';
    src: url('MonaSans-Variable.woff2') format('woff2-variations');
    font-weight: 200 900;
    font-stretch: 75% 125%;
    font-style: normal;
    font-display: swap;
}
:root {
    --font-body: "InterVariable", system-ui, -apple-system, sans-serif;
    --font-display: "MonaSans", "InterVariable", system-ui, sans-serif;
}
.font-inter { font-family: var(--font-body); }
.font-mona { font-family: var(--font-display); }
"""
        css_path = self.assets_path / "fonts.css"
        with open(css_path, 'w', encoding='utf-8') as css_file:
            css_file.write(css_content)

    def create_font_info_json(self):
        font_info = {
            "fonts": {
                "inter": {
                    "name": "Inter Variable",
                    "file": "InterVariable.woff2",
                    "family": "InterVariable",
                    "weights": "100-900",
                    "license": "SIL Open Font License",
                    "source": "https://github.com/rsms/inter",
                    "usage": "Primary UI font, body text, interface elements"
                },
                "mona_sans": {
                    "name": "Mona Sans Variable",
                    "file": "MonaSans-Variable.woff2",
                    "family": "MonaSans",
                    "weights": "200-900",
                    "width": "75%-125%",
                    "license": "SIL Open Font License",
                    "source": "https://github.com/github/mona-sans",
                    "usage": "Headers, display text, emphasis"
                }
            },
            "download_date": time.strftime("%Y-%m-%d %H:%M:%S"),
            "css_usage": {
                "body": "font-family: var(--font-body);",
                "headings": "font-family: var(--font-display);",
                "variables": {
                    "--font-body": "\"InterVariable\", system-ui, sans-serif",
                    "--font-display": "\"MonaSans\", \"InterVariable\", system-ui, sans-serif"
                }
            }
        }
        json_path = self.assets_path / "font-info.json"
        with open(json_path, 'w', encoding='utf-8') as json_file:
            json.dump(font_info, json_file, indent=2, ensure_ascii=False)

    def verify_downloads(self):
        for font_key, font_config in self.fonts.items():
            font_path = self.assets_path / font_config['filename']
            if not font_path.exists() or font_path.stat().st_size < 50000:
                raise FileNotFoundError(f"{font_config['name']} not found or file too small.")

    def run(self):
        print("=== TENET Tech Font Downloader ===")
        self.create_directory()
        print("Downloading Inter Variable font...")
        self.download_inter_font()
        print("Downloading Mona Sans Variable font...")
        self.download_mona_sans_font()
        print("Generating CSS...")
        self.generate_css_file()
        print("Creating font info JSON...")
        self.create_font_info_json()
        print("Verifying downloads...")
        self.verify_downloads()
        print("All fonts downloaded and processed successfully!")

if __name__ == "__main__":
    downloader = FontDownloader()
    downloader.run()
